# electron_playground
* An event logger of the day
	- An app that can prompt you to log what are you currently doing and saves the data
	- It can be enabled in the system-tray whenever you want to log an event
	- Main app window is used to render all of your saved data

* TODO
	- Provide an analysis of daily activity
	- Provide a possible plan for next week using that analysis
	- Evolve iteself to be an smart planner
	- A better front end 
